
const chat = document.getElementById("chat");
const form = document.getElementById("chat-form");
const input = document.getElementById("message");
const newChat = document.getElementById("new-chat");

function adicionarMensagem(texto, tipo) {
    const mensagem = document.createElement("div");

    mensagem.style.maxWidth = "750px";
    mensagem.style.width = "fit-content";
    mensagem.style.padding = "15px 20px";
    mensagem.style.margin = "15px auto";
    mensagem.style.borderRadius = "15px";
    mensagem.style.lineHeight = "1.6";
    mensagem.style.whiteSpace = "pre-wrap";
    mensagem.style.wordBreak = "break-word";

    if (tipo === "usuario") {
        mensagem.style.background = "#8054ad";
        mensagem.style.color = "white";
        mensagem.style.marginLeft = "auto";
    } else {
        mensagem.style.background = "#eee6f7";
        mensagem.style.color = "#30263d";
        mensagem.style.marginRight = "auto";
    }

    mensagem.textContent = texto;
    chat.appendChild(mensagem);
    chat.scrollTop = chat.scrollHeight;
}

async function enviarPergunta(pergunta) {
    if (!pergunta.trim()) return;

    document.querySelector(".welcome")?.remove();

    adicionarMensagem(pergunta, "usuario");

    input.value = "";
    input.disabled = true;

    try {
        const resposta = await fetch("http://localhost:3000/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ pergunta })
        });

        const dados = await resposta.json();

        if (!resposta.ok) {
            throw new Error(dados.erro || "Erro no servidor.");
        }

        adicionarMensagem(dados.resposta, "bot");

    } catch (erro) {
        console.error(erro);
        adicionarMensagem(
            "Não consegui conectar ao servidor. Verifique se ele está ligado.",
            "bot"
        );
    }

    input.disabled = false;
    input.focus();
}

form.addEventListener("submit", function(event) {
    event.preventDefault();
    enviarPergunta(input.value);
});

document.querySelectorAll(".suggestion").forEach(botao => {
    botao.addEventListener("click", () => {
        enviarPergunta(botao.textContent);
    });
});

newChat.addEventListener("click", () => {
    chat.innerHTML = `
        <div class="welcome">
            <div class="avatar">✦</div>
            <h1>Olá! Eu sou o HairBot 💜</h1>
            <p>Estou aqui para ajudar você a conhecer melhor seu cabelo!</p>
        </div>
    `;
});
