
const express = require("express");
const cors = require("cors");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("HAIRBOT NOVO - SERVIDOR FUNCIONANDO 💜");
});

function responder(pergunta) {
    const texto = pergunta.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

    if (texto.includes("oi") || texto.includes("ola")) {
        return "Olá! 💜 Sou o HairBot! Como posso ajudar com seus cabelos?";
    }

    if (texto.includes("hidrata")) {
        return "💧 HIDRATAÇÃO CAPILAR\n\nA hidratação ajuda a repor a água dos fios.\n\nComo fazer:\n1. Lave o cabelo com shampoo.\n2. Retire o excesso de água.\n3. Aplique uma máscara hidratante no comprimento e nas pontas.\n4. Aguarde o tempo indicado na embalagem.\n5. Enxágue bem.\n\nFaça a hidratação conforme a necessidade dos seus fios!";
    }

    if (texto.includes("nutri")) {
        return "🌿 NUTRIÇÃO CAPILAR\n\nA nutrição ajuda a repor os lipídios dos fios. Máscaras com óleos vegetais podem ajudar na maciez e no ressecamento.";
    }

    if (texto.includes("reconstr")) {
        return "💜 RECONSTRUÇÃO CAPILAR\n\nA reconstrução ajuda a repor proteínas da fibra capilar. Produtos com queratina podem auxiliar nos cuidados com fios danificados. Evite exagerar na frequência.";
    }

    if (texto.includes("cronograma")) {
        return "✨ CRONOGRAMA CAPILAR\n\nO cronograma possui três etapas:\n\n💧 Hidratação: reposição de água.\n🌿 Nutrição: reposição de lipídios.\n💜 Reconstrução: reposição de proteínas.\n\nA rotina deve respeitar as necessidades do cabelo.";
    }

    if (texto.includes("tipos de cabelo") || texto.includes("tipo de cabelo")) {
        return "💇 TIPOS DE CABELO\n\nTipo 1: Liso.\nTipo 2: Ondulado.\nTipo 3: Cacheado.\nTipo 4: Crespo.\n\nCada grupo possui subdivisões A, B e C.";
    }

    if (texto.includes("cachead") || texto.includes("cacho")) {
        return "💜 CUIDADOS COM CACHOS\n\n1. Use produtos adequados.\n2. Desembarace delicadamente.\n3. Utilize creme de pentear.\n4. Evite esfregar os fios com a toalha.\n5. Hidrate conforme a necessidade.";
    }

    if (texto.includes("crespo")) {
        return "🌿 CUIDADOS COM CABELO CRESPO\n\nUse produtos hidratantes, condicionador e desembarace delicadamente. Cremes de pentear podem ajudar na finalização.";
    }

    if (texto.includes("liso")) {
        return "✨ CUIDADOS COM CABELO LISO\n\nUse shampoo e condicionador adequados. Faça hidratações conforme a necessidade e evite exagerar na quantidade de produtos.";
    }

    if (texto.includes("ondulado")) {
        return "🌊 CUIDADOS COM CABELO ONDULADO\n\nProdutos leves, condicionamento e finalização suave podem ajudar a valorizar as ondas.";
    }

    if (texto.includes("caspa")) {
        return "A caspa pode ter diferentes causas. Um shampoo anticaspa pode ajudar. Se houver irritação persistente, procure um dermatologista.";
    }

    if (texto.includes("queda")) {
        return "A queda de cabelo pode ter várias causas. Se for intensa ou persistente, procure um dermatologista.";
    }

    return "Ainda não tenho uma resposta cadastrada para esse assunto. 💜 Experimente perguntar sobre hidratação, nutrição, reconstrução, cronograma capilar ou tipos de cabelo!";
}

app.post("/chat", (req, res) => {
    const pergunta = req.body.pergunta;

    if (!pergunta || !pergunta.trim()) {
        return res.status(400).json({ erro: "Digite uma pergunta!" });
    }

    res.json({
        resposta: responder(pergunta)
    });
});

app.listen(3000, () => {
    console.log("HAIRBOT NOVO INICIADO!");
    console.log("http://localhost:3000");
});
